# Catalog management

The catalog is data-driven. Category prefixes include AYT, ORN, LOG, SWL, PAT, and FLR.

GitHub Pages is static, so a browser cannot persist catalog edits directly into the repository. The structure is prepared for a future GitHub-connected CMS/workflow. Until then, catalog changes are committed to the repository using the same data structure.

Only publish original or properly licensed artwork. The initial watermarked reference images are not products.
