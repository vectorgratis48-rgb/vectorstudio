const WA_NUMBER='6285692520888';
function waLink(message){return `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(message)}`}
document.querySelectorAll('[data-wa]').forEach(el=>{el.href=waLink(el.dataset.message||'Halo, saya ingin bertanya tentang koleksi vector di website.');el.target='_blank';el.rel='noopener noreferrer'});
const toggle=document.querySelector('.nav-toggle'),nav=document.querySelector('.site-nav');
if(toggle&&nav){toggle.addEventListener('click',()=>{const open=nav.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open));})}
const io='IntersectionObserver' in window?new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)e.target.classList.add('visible')}),{threshold:.08}):null;
document.querySelectorAll('.reveal').forEach(e=>io?io.observe(e):e.classList.add('visible'));
